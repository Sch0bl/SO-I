#include "read_write.h"
#include <stdlib.h>

struct __MyStruct {
    int reading;
		int writing;
    pthread_mutex_t mutex;
		pthread_cond_t cv;
    sem_t sem;
};

void rw_struct_init(struct_t *rw_struct){
	struct_t temp = *rw_struct;
	temp = malloc(sizeof(struct __MyStruct));
	pthread_mutex_init(&temp->mutex, NULL);
	pthread_cond_init(&temp->cv, NULL);
	sem_init(&temp->sem, 0,0);
}

void write_lock(struct_t rw_struct){
	pthread_mutex_lock(&rw_struct->mutex);
	/* sem_wait(&rw_struct->sem); */
	rw_struct->writing = 1;
	while (rw_struct->reading != 0){
		rw_struct->writing = 0;
		/* sem_post(&rw_struct->sem); */
		pthread_cond_wait(&rw_struct->cv, &rw_struct->mutex);
		rw_struct->writing = 1;
		/* sem_wait(&rw_struct->sem); */
	}
	/* sem_post(&rw_struct->sem); */
}

void write_unlock(struct_t rw_struct){
	rw_struct->writing = 0;
	pthread_cond_broadcast(&rw_struct->cv);
	pthread_mutex_unlock(&rw_struct->mutex);
}

void read_lock(struct_t rw_struct){
	if (rw_struct->writing == 0)
		sem_post(&rw_struct->sem);
	sem_wait(&rw_struct->sem);
	rw_struct->reading++;
	sem_post(&rw_struct->sem);
	/* pthread_mutex_lock(&rw_struct->mutex); */
	/* while (rw_struct->writing){ */
	/* 	pthread_cond_wait(&rw_struct->cv, &rw_struct->mutex); */
	/* } */
	/* pthread_mutex_unlock(&rw_struct->mutex); */
}

void read_unlock(struct_t rw_struct){
	sem_wait(&rw_struct->sem);
	rw_struct->reading--;
	sem_post(&rw_struct->sem);
}

void rw_struct_close(struct_t rw_struct){
	pthread_cond_destroy(&rw_struct->cv);
	pthread_mutex_destroy(&rw_struct->mutex);
	sem_destroy(&rw_struct->sem);
	free(rw_struct);
}
